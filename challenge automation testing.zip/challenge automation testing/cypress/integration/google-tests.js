import PageInteractions from '../utilities/page-interactions.js';
import CommonMethods from '../utilities/common-methods.js';
import Assertions from '../utilities/assertions.js';

let page = new PageInteractions();
let common = new CommonMethods();
let assert = new Assertions();

const googleData = require('../fixtures/google-data.json');

const fixtures = {
  "googleData" : 'google-data.json',
}

describe('google Checks', function() {
    before(function() {
      page.readFixtures(fixtures)
    });
  
    describe('Happy Scenario', function() {
      it('happy scenario ', function() {
        cy.visit("");
        page.writeTxt(this.googleData.searchBar.selector,this.googleData.searchBar.value)
        page.clickBtnUsingContains(this.googleData.searchButton.value)
        assert.isTxtVisible(this.googleData.searchResult.value)
        
      });
      it('login ', function() {
        cy.visit("");
       
        page.writeTxt(this.googleData.loginButton.emailSelector,this.googleData.loginButton.email)
        page.writeTxt(this.googleData.loginButton.passwordSelector,this.googleData.loginButton.password)
        page.clickBtnUsingContains(this.googleData.loginButton.signInButton)
       
       
      });
      it('check did you mean appears when there is typos in search results', function() {
        cy.visit("");
        page.writeTxt(this.googleData.searchBar.selector,this.googleData.typoInSearch.value)
        page.clickBtnUsingContains(this.googleData.searchButton.value)
        assert.isTxtVisible(this.googleData.typoInSearch.assertValue)
       
      });

      it('Invalid Search Result ', function() {
        cy.visit("");
        page.writeTxt(this.googleData.searchBar.selector,this.googleData.invalidSearch.value)
        page.clickBtnUsingContains(this.googleData.searchButton.value)
        assert.isTxtVisible(this.googleData.invalidSearch.assertValue)
      });
      it('Check Auto-Suggesstions',function(){
        cy.visit("");
        page.writeTxt(this.googleData.searchBar.selector,this.googleData.autoSuggesstions.value)
        assert.isTxtVisible(this.googleData.autoSuggesstions.assertSelector1,this.googleData.autoSuggesstions.assertValue1)
        assert.isTxtVisible(this.googleData.autoSuggesstions.assertSelector2,this.googleData.autoSuggesstions.assertValue2)

      });
      it('check search results are displayed based on localiztion',function(){
        cy.visit("");
        page.writeTxt(this.googleData.searchBar.selector,this.googleData.searchBar.value)
        page.clickBtnUsingContains(this.googleData.searchButton.value)
        assert.isTxtVisible(this.googleData.location.selector,this.googleData.location.value)

      });
      it('check nothing occur when tapping enter with empty search bar',function(){
        cy.visit("");
        page.clickBtnUsingContains(this.googleData.searchButton.value)
        assert.isTxtVisible(this.googleData.searchBar.feelingLuckyButtonSelector,this.googleData.searchBar.feelingLuckyButtonValue)

      });

    });
});